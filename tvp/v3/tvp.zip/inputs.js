var inputs = {
    IDs: ['inputA', 'inputB', 'inputC'],
    idToPoint: {}, //this location includes only the X cordinate
    startPoint: null,
    connectedTo: {}
}

var startAt = canvas.width/10 - canvas.width/10 % amount + amount*2
updateInputLoc()

function updateInputLoc(){
    startAt = canvas.width/10 - canvas.width/10 % amount + amount*2

    for(let id of inputs.IDs){
        
        let inputElement = document.getElementById(id)

        inputs.idToPoint[id] = startAt
        
        inputElement.style.left = `${startAt}px`
        inputElement.style.width = `${amount*2-2}px`

        startAt += amount*3
    }
}

window.addEventListener('resize', updateInputLoc)
