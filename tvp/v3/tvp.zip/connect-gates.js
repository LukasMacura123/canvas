var output

window.addEventListener('mousedown', (e) => {
    if(tools.cable && e.button == 0 && cable.disconnectGate == null){
        //create connection
        for(let id of gateInfo.gateIds){
            
            if(e.clientX > gateInfo.idToLoc[id][0]*amount && e.clientX < gateInfo.idToLoc[id][0]*amount + amount*4&&
            e.clientY > gateInfo.idToLoc[id][1]*amount && e.clientY < gateInfo.idToLoc[id][1]*amount + amount*6){
                
                if(cable.startGate == null){
                    cable.startGate = id
                }else{  
                    if(cable.startGate != id){
                        if(output){
                            if(cable.connectedGates[cable.startGate] == null) cable.connectedGates[cable.startGate] = [id]
                            else{
                                if(cable.connectedGates[cable.startGate].length < 16)cable.connectedGates[cable.startGate].push(id)
                                else console.error("you can't have more than 15 inputs per logic gate");
                            }
                        }else{
                            if(cable.connectedGates[id] == null) cable.connectedGates[id] = [cable.startGate]
                            else{
                                if(cable.connectedGates[id].length < 16) cable.connectedGates[id].push(cable.startGate)
                                else console.error("you can't have more than 15 inputs per logic gate")
                            }
                        }
                        cable.startGate = null
                    }
                }
            }
        }
        if(inputs.startPoint == null){
            let X, Y
            
            if(e.clientX % amount < amount/2) X = e.clientX - e.clientX % amount
            else X = e.clientX - e.clientX % amount + amount
            
            if(e.clientY % amount < amount/2) Y = e.clientY - e.clientY % amount
            else Y = e.clientY - e.clientY % amount + amount

            for(let id of inputs.IDs){
                if(e.clientX > inputs.idToPoint[id] && e.clientX < inputs.idToPoint[id] + amount*3){
                    inputs.startPoint = [X, Y]
                }
            }
        }
        
    }else if(tools.cable && e.button == 2 && cable.startGate == null){
        //remove connection
        for(let id of gateInfo.gateIds){

            if(e.clientX > gateInfo.idToLoc[id][0]*amount && e.clientX < gateInfo.idToLoc[id][0]*amount + amount*4&&
                e.clientY > gateInfo.idToLoc[id][1]*amount && e.clientY < gateInfo.idToLoc[id][1]*amount + amount*6){
                    if(inputs.startPoint == null){

                        if(cable.disconnectGate == null){
                            cable.disconnectGate = id
                            document.getElementById(`${id}text`).style.color = 'red'
                        }else{
                            try{
                                if(output){
                                    cable.connectedGates[id].splice(cable.connectedGates.indexOf(cable.disconnectGate), 1)
                                }else{
                                    cable.connectedGates[cable.disconnectGate].splice(cable.connectedGates.indexOf(id), 1)
                                }

                                document.getElementById(`${cable.disconnectGate}text`).style.color = 'white'
                                cable.disconnectGate = null
                            }catch(error){console.error('these gates were not connected in the first place')}
                        }
                    }else{
                        inputs.connectedTo[inputs.startPoint] = id
                        console.log(inputs.connectedTo)
                        inputs.startPoint = null
                    }
                }
                
        }
    }
})
window.addEventListener('keypress', (e) => {
    if((cable.startGate != null || cable.disconnectGate != null) && (e.key == 'q' || e.key == ' ')){
        cable.startGate = null
        document.getElementById(`${cable.disconnectGate}text`).style.color = 'white'
        cable.disconnectGate = null
        inputs.startPoint = null
    }
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    drawGrid()
    displayConnections()
})
window.addEventListener('mousemove', (e) => {
    if(tools.cable){

        let YI

        if(e.clientY % amount < amount/2) YI = e.clientY - e.clientY % amount
        else YI = e.clientY - e.clientY % amount + amount


        for(let id of gateInfo.gateIds){
            
            if(e.clientX > gateInfo.idToLoc[id][0]*amount && e.clientX < gateInfo.idToLoc[id][0]*amount + amount*4&&
                e.clientY > gateInfo.idToLoc[id][1]*amount && e.clientY < gateInfo.idToLoc[id][1]*amount + amount*6){
                    
                    let gateLoc = [gateInfo.idToPoint[id][0]*amount, gateInfo.idToPoint[id][1]*amount]
                    if(cable.startGate == null)
                        if(e.clientX < gateLoc[0]+amount*2){
                        
                            drawCircle(gateLoc[0]+amount/2, gateLoc[1]+amount*3, canvas.height/72, 90, 270, 'rgba(51,51,143,0.8)')
                            if(cable.startGate == null) output = false
                        
                        }else{
                        
                            drawCircle(gateLoc[0]+amount*4-amount/2, gateLoc[1]+amount*3, canvas.height/72, 270, 90, 'rgba(143,51,51,0.8)')    
                            if(cable.startGate == null) output = true
                        } 
                    else{
                        if(cable.startGate != id){
                            if(output){
                            
                                drawCircle(gateLoc[0]+amount/2, gateLoc[1]+amount*3, canvas.height/72, 90, 270, 'rgba(51,51,143,0.8)')
                                if(cable.startGate == null) output = false
                            
                            }else{
                            
                                drawCircle(gateLoc[0]+amount*4-amount/2, gateLoc[1]+amount*3, canvas.height/72, 270, 90, 'rgba(143,51,51,0.8)')    
                                if(cable.startGate == null) output = true
                            }
                        }
                    }
                }
    
        }
        for(let id of inputs.IDs){
            if(e.clientX > inputs.idToPoint[id] && e.clientX < inputs.idToPoint[id] + amount*3){
            
                inputs.cursor = YI
                drawCircle(inputs.idToPoint[id] + amount*2, YI, canvas.height/108, 0, 360, 'white')
            }
        }
        if(cable.startGate != null){
            let X = !output ? gateInfo.idToPoint[cable.startGate][0]*amount + amount/3 : gateInfo.idToPoint[cable.startGate][0]*amount + amount*4 - amount/3,
            Y = gateInfo.idToPoint[cable.startGate][1]*amount + amount*3
            
            drawLine(X, Y, e.clientX, e.clientY, 'gray')
        }
        if(inputs.startPoint != null){
            drawLine(inputs.startPoint[0], inputs.startPoint[1], e.clientX, e.clientY, 'gray')
        }
    }
})
window.addEventListener('contextmenu', (e) => {
    if(tools.cable || tools.gate){
        e.preventDefault()
    }
})