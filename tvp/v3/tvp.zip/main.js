/** @type {HTMLCanvasElement} */
const canvas = document.getElementById('myCanvas');
const ctx = canvas.getContext('2d');

canvas.width  = window.innerWidth
canvas.height = window.innerHeight

var clickedOnGate, amount

var container = document.getElementById('gateContainer')
var modeText  = document.getElementById('switchModes'), modeOptions = ['add', 'connect', 'move', 'change']

//'activeGate': '<div class="gate" id="activeGate"><div class="gateBody"><div class="gateName" id="activeGateText"></div></div></div>'
var gateInfo = {
    allGates: {},
    gateIds: [],

    idToLoc: {},
    idToContent: {},
    idToPoint: {},

    inputs: ['1', '&','N','N1', 'N&'],
    activeInput: '&',
    freeSpace: true,

    nextId: 1
}

var tools = {
    cable: false,
    gate: true,
    change: false,
    loc: false,
}

var cable = {
    startGate: null,
    disconnectGate: null,
    connectedGates: [],
    output: true
}
var moveGateId = null
//create elements and their values that will be used later on
container.innerHTML = '<div class="gate" id="activeGate"><div class="gateBody"><div class="gateName" id="activeGateText"></div></div></div>'

var activeGate = document.getElementById('activeGate'), activeGateText = document.getElementById('activeGateText')
activeGate.style.top = '0', activeGate.style.left = '0', activeGate.style.opacity = '0.5'
activeGateText.textContent = gateInfo.activeInput

drawGrid()

function clickedOn(gateID){
    if(tools.change){
        let element = document.getElementById(`${gateID}text`)
        element.textContent = gateInfo.inputs.indexOf(element.textContent) >= gateInfo.inputs.length-1 ? gateInfo.inputs[0] : gateInfo.inputs[gateInfo.inputs.indexOf(element.textContent)+1]

        // document.getElementById(`${gateID}text`).textContent = gateInfo.inputs.indexOf(document.getElementById(`${gateID}text`).textContent) >= 3 ? gateInfo.inputs[0] : gateInfo.inputs[gateInfo.inputs.indexOf(document.getElementById(`${gateID}text`).textContent)+1]
        gateInfo.idToContent[gateID] = element.textContent
    
    }else if(tools.loc && moveGateId == null){
        moveGateId = gateID
    }
}

function switchModes(){
    let index = modeOptions.indexOf(modeText.textContent)
    if(modeOptions.length-1 == index){
        modeText.textContent = modeOptions[0]
    }else{
        modeText.textContent = modeOptions[index+1]
    }
    switch(modeText.textContent){
        case modeOptions[0]:
            tools.gate = true, tools.location = false, tools.cable = false, tools.change = false
            break

        case modeOptions[1]:
            tools.cable = true, tools.gate = false, tools.loc = false, tools.change = false
            break

        case modeOptions[2]:
            tools.loc = true, tools.gate = false, tools.cable = false, tools.change = false
            break
        
            case modeOptions[3]:
            tools.change = true, tools.loc = false, tools.gate = false, tools.cable = false
            break
    }
    if(!tools.gate) activeGate.style.top = '110vh'
    else if(!cable) output = null, cable.startGate = null
}
function displayGatesHtml(){
    let finallString = ''

    for(let id of gateInfo.gateIds){
        finallString += gateInfo.allGates[id]
    }
    container.innerHTML = `${finallString}<div class="gate" id="activeGate"><div class="gateBody"><div class="gateName" id="activeGateText"></div></div></div>`

    activeGate = document.getElementById('activeGate'), activeGateText = document.getElementById('activeGateText')
    activeGateText.textContent = gateInfo.activeInput
    activeGate.style.opacity = '0.5'

    for(let id of gateInfo.gateIds){
        document.getElementById(`${id}text`).textContent = gateInfo.idToContent[id]
    }
}
function updateLocation(){
    for(let id of gateInfo.gateIds){
        let gateElement = document.getElementById(id)
        
        gateElement.style.left = `${gateInfo.idToLoc[id][0]*amount}px`
        gateElement.style.top = `${gateInfo.idToLoc[id][1]*amount}px`
    }
}
function drawGrid(){
    let x = canvas.height, y = canvas.height
    
    if(y > x) amount = y/48
    else amount = x/48
    
    ctx.fillStyle = 'rgb(15,15,15)'

    for(let i = 1; i <= 100; i++){
        ctx.fillRect(0, i*(amount), canvas.width, 2)
        ctx.fillRect(i*(amount), 0, 2, canvas.height)
    }
}
function drawCircle(X, Y, size, ang1, ang2, color){
    ctx.fillStyle = color
    ctx.beginPath()
    ctx.arc(X, Y, size, (Math.PI*ang1)/180, (Math.PI*ang2)/180)
    ctx.fill()
    ctx.closePath()
}
function gateInputRatio(gateID){
    let gateOccurrence = 0
    for(let id of gateInfo.gateIds){
        if(cable.connectedGates[id] != null){
            for(let j of cable.connectedGates[id]){
                if(j == gateID) gateOccurrence++
            }
        }
    }

    return gateOccurrence
}
function displayConnections(){
    let startAt = {}

    for(let i of gateInfo.gateIds){
        let startX = gateInfo.idToPoint[i][0]*amount + amount*4 - amount/3, startY = gateInfo.idToPoint[i][1]*amount + amount*3-2
        
        if(cable.connectedGates[i] != null){
            for(let j of cable.connectedGates[i]){
                
                let occurrence = gateInputRatio(j)
                let distance = (amount*6)/(occurrence+1)
                
                if(startAt[j] == null) startAt[j] = distance
                else startAt[j] += distance
            
                let endX = gateInfo.idToPoint[j][0]*amount + amount/2, endY = gateInfo.idToPoint[j][1]*amount+startAt[j]-2
                if(document.getElementById(i).textContent.includes('N')) drawLine(startX, startY, endX, endY, 'blue')
                else drawLine(startX, startY, endX, endY, 'red')
            }
        }
    }
}
function drawLine(startX, startY, endX, endY, color){
    ctx.beginPath()

    ctx.strokeStyle = color
    ctx.lineWidth = 5

    ctx.moveTo(startX, startY)
    ctx.lineTo(endX, endY)

    ctx.stroke()
}
window.addEventListener('keypress', (e) => {if(e.key == ' '){switchModes()}})
window.addEventListener('resize', () => {
    //in case of resizing the browser window
    canvas.width = window.innerWidth, canvas.height = window.innerHeight
    drawGrid()
    updateLocation()
})

window.addEventListener('mousemove', (e) => {
    //update visual aids of the website (cursor and gate position)
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    drawGrid()
    displayConnections()
    drawLine()

    if(tools.gate){
        activeGate.style.top = `${e.clientY + 10}px`
        if(e.clientX > startAt) activeGate.style.left = `${e.clientX + 10}px`
        else activeGate.style.left = `${startAt + 10}px`
    }
    if(moveGateId != null){
        document.getElementById(moveGateId).style.left = `${e.clientX+10}px`
        document.getElementById(moveGateId).style.top  = `${e.clientY+10}px`
        
        gateInfo.idToPoint[moveGateId] = [(e.clientX)/amount, (e.clientY)/amount]

        displayConnections()
    }
    if(tools.gate || tools.loc){
        ctx.fillStyle = 'rgb(143, 51, 143)'
        for(let i = 0; i < 100; i++){
            for(let j = 0; j < 100; j++){
                if((e.clientY > i*amount - amount/2 && e.clientY < i*amount + amount/2) &&
                    (e.clientX > j*amount - amount/2 && e.clientX < j*amount + amount/2)){
                        ctx.fillRect(j*amount -2, i*amount -2, 6, 6)
                }
            }
        }
    }
    
    //establish if there is a space to playe another gate
    let yesNo = true

    let POINTX, POINTY

    if(e.clientX % amount < amount/2) POINTX = e.clientX - e.clientX % amount
    else POINTX = e.clientX - e.clientX % amount + amount
        
    if(e.clientY % amount < amount/2) POINTY = e.clientY - e.clientY % amount
    else POINTY = e.clientY - e.clientY % amount + amount

    for(let i of gateInfo.gateIds){

        let X = gateInfo.idToLoc[i][0]*amount, Y = gateInfo.idToLoc[i][1]*amount
        
        if(moveGateId != i){
            if(!((POINTX > X + amount*3 || POINTX < X - amount*4) ||
            (POINTY > Y + amount*5 || POINTY < Y - amount*6))){
                    yesNo = false
            }
        }
    }
    gateInfo.freeSpace = yesNo
    if(!yesNo) activeGate.style.opacity = '0.1'
    else activeGate.style.opacity = '0.5'
    
})
window.addEventListener('mousedown', (e) => {
    //elstablish where will be the newly added gate located
    let X, Y
     
    if(e.clientX % amount < amount/2) X = e.clientX - e.clientX % amount
    else X = e.clientX - e.clientX % amount + amount
    
    if(e.clientY % amount < amount/2) Y = e.clientY - e.clientY % amount
    else Y = e.clientY - e.clientY % amount + amount
    
    if(e.button == 0 && gateInfo.freeSpace && e.clientX > canvas.width/10 && tools.gate && startAt < e.clientX){
        //create another gate
        let id = `gate${gateInfo.nextId}`, idCnt = `gate${gateInfo.nextId}text`
        gateInfo.nextId++
    
        //save necessary information
        gateInfo.allGates[id] = `<div class="gate" id="${id}" onclick="clickedOn('${id}')"><div class="gateBody"><div class="gateName" id="${idCnt}">${gateInfo.activeInput}</div></div></div>`
        gateInfo.gateIds.push(id)

        gateInfo.idToLoc[id] = [(X + amount/2.35)/amount, (Y + amount/8)/amount]
        gateInfo.idToPoint[id] = [X/amount, Y/amount]
        gateInfo.idToContent[id] = gateInfo.activeInput

        //update website with newly added elements
        displayGatesHtml()
        document.getElementById(idCnt).textContent = gateInfo.activeInput
    
        updateLocation()
        gateInfo.freeSpace = false

    }else if(e.button == 1 && cable.startGate == null){
        //cleareverything
        ctx.clearRect(0, 0, canvas.width, canvas.height)
        drawGrid()
        //search for clicked on gate
        for(let id of gateInfo.gateIds){
            if(e.clientX > gateInfo.idToLoc[id][0]*amount && e.clientX < gateInfo.idToLoc[id][0]*amount + amount*4 &&
            e.clientY > gateInfo.idToLoc[id][1]*amount && e.clientY < gateInfo.idToLoc[id][1]*amount + amount*4){

                gateInfo.gateIds.splice(gateInfo.gateIds.indexOf(id), 1)
                gateInfo.allGates[id] = null
                gateInfo.idToContent[id] = null
                gateInfo.idToLoc[id] = null
                cable.connectedGates[id] = null

                for(let i of gateInfo.gateIds){
                    if(cable.connectedGates[i] != null){
                        for(let j = 0; j<16; j++){
                            if(cable.connectedGates[i].includes(id)){
                                cable.connectedGates[i].splice(cable.connectedGates[i].indexOf(id), 1)
                            }
                        }
                    }
                }
    
                //update website with newly added elements
                displayGatesHtml()
            }
        }
    }/*else if(e.button == 2){
        for(let id of gateInfo.gateIds){
            if(e.clientX > gateInfo.idToLoc[id][0]*amount && e.clientX < gateInfo.idToLoc[id][0]*amount + amount*4 &&
            e.clientY > gateInfo.idToLoc[id][1]*amount && e.clientY < gateInfo.idToLoc[id][1]*amount + amount*4){
                console.log(id)
            }
        }
    }*/
    if(tools.gate){
    
        activeGate.style.top = `${e.clientY + 10}px`
        if(e.clientX > canvas.width/10) activeGate.style.left = `${e.clientX + 10}px`
        else activeGate.style.left = `${canvas.width/10 + 10}px`
    
    }if(moveGateId != null && gateInfo.freeSpace && e.button == 0 && e.clientX > canvas.width/10){
        gateInfo.idToLoc[moveGateId] = [(X + amount/2.35)/amount, (Y + amount/8)/amount]
        gateInfo.idToPoint[moveGateId] = [X/amount, Y/amount]

        moveGateId = null
    }
    ctx.clearRect(0,0,canvas.width,canvas.height)
    drawGrid()
    displayConnections()
    updateLocation()
})